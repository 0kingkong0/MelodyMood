# MelodyMood 
# By: Ali Asghar, Butta Adem, and Aaron Tir 
# WinHacks 2024
# 2024-02-17
#===========================================


# Import Statements
# --------------------

import spotipy
import openai
from spotipy.oauth2 import SpotifyOAuth
import time


# Setting up the Flask App 

# Global variables and authentication
# ------------------------------------

#-----------------------------------------------------------
from flask import Flask, render_template, redirect, url_for, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homepage.html')

@app.route('/multiple')
def second():
    return render_template('multiple-choice-container.html')
if __name__ == '__main__':
    app.run(debug=True)
#------------------------------------------------------------

# OpenAi vairables 
openai.api_key = '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'

# Spotify variables 
spotifScope = "playlist-modify-public playlist-modify-private user-read-playback-state user-modify-playback-state"

spotifyUsername = '9xupam0ir3i5rui5d8pwq6jog'

spotifyClientID = '0880d2ec88124bf29e64f63aa5f6658f'

spotifyClientSecret = 'e4e1203615294222b264cf92a05d8002'

spotifyRedirectURI = 'http://127.0.0.1:8080'

# Creating the Spotify token 
spotifyToken = SpotifyOAuth (scope = spotifScope, username = spotifyUsername, client_id = spotifyClientID, client_secret = spotifyClientSecret, redirect_uri = spotifyRedirectURI)

# Create the spotify object 
spotifyObject = spotipy.Spotify(auth_manager = spotifyToken)

# Variables for logic 
aCount = 0 # Corresponds to personlity 1
bCount = 0 # Corresponds to personlity 2
cCount = 0 # Corresponds to personlity 3
dCount = 0 # Corresponds to personlity 4
eCOunt = 0 # Corresponds to personlity 5
fCount = 0 # Corresponds to 'All of the above' 




#-------------------------------------------------------------------------
@app.route('/create_playlist', methods=['POST'])
def create_playlist():
    playlistName = request.form['playlistName']
    playlistDescription = request.form['playlistDescription']
    numOfSongs = int(request.form['numOfSongs'])
    musicPreference = request.form['musicPreference']

    # Assuming your existing logic for Spotify playlist creation here
    playlist = spotifyObject.user_playlist_create(user=spotifyUsername, name=playlistName, public=True, description=playlistDescription)
    playlistID = playlist['id']

    return f"Playlist '{playlistName}' created successfully with ID: {playlistID}"

if __name__ == '__main__':
    app.run(debug=True)
#-------------------------------------------------------------------------









# Assigning personality type based on given answers
#---------------------------------------------------
# --------------------------------------------------


# Asking the first question
answer = input (" \n\n What do you like? (A = Pop, B = Rap, C = Country)")

if (answer == "A"):
    aCount+=1
elif (answer == "B"):
    bCount+=1
elif (answer == "C"):
    cCount+=1
else:
    print("Invalid Input")    


# Asking the second question
answer = input (" \n\n What do you like? (A = Pop, B = Rap, C = Country)")

if (answer == "A"):
    aCount+=1
elif (answer == "B"):
    bCount+=1
elif (answer == "C"):
    cCount+=1
else:
    print("Invalid Input")    

       
# Asking the third question    
answer = input ("\n\n What do you like? (A = Pop, B = Rap, C = Country)")
if (answer == "A"):
    aCount+=1
elif (answer == "B"):
    bCount+=1
elif (answer == "C"):
    cCount+=1
  

# Asking the fourth question        
answer = input (" \n\n What do you like? (A = Pop, B = Rap, C = Country)")

if (answer == "A"):
    aCount+=1
elif (answer == "B"):
    bCount+=1
elif (answer == "C"):
    cCount+=1
else:
    print("Invalid Input")    


# Asking the fifth question    
answer = input (" \n\n What do you like? (A = Pop, B = Rap, C = Country)")

if (answer == "A"):
    aCount+=1
elif (answer == "B"):
    bCount+=1
elif (answer == "C"):
    cCount+=1
else:
    print("Invalid Input")    

       
# Based on the answers, assign their overall personality
if (aCount > bCount and aCount > cCount):
    personalityGenre = "Pop" 

elif (bCount > aCount and bCount > cCount):
    personalityGenre = "Rap"

elif (cCount > aCount and cCount > bCount):
    personalityGenre = "Country"


# Use openai to get songs based on the personality chosen 
# -------------------------------------------------------
# -------------------------------------------------------
        
# Get User Prompt and System Role 
prompt = f"Recommend me {numOfSongs} songs for someone who some who likes {personalityGenre}"

# Provide a list of messages for the chat model
messages = [
    {"role": "system", "content": "You are a song recommender from spotify. Give your reponses as just the names of the song, without the aritist."},
    {"role": "user", "content": prompt},
]

# Make an openAPI call to generate a chat-based completion
response = openai.ChatCompletion.create(
model="gpt-4",
messages=messages
)

# Print the generated text from openAI resonse
openAiSongSuggestions = response['choices'][0]['message']['content']


# Make for loop to iterate through the titles
# --------------------------------------------
for currentSongTitle in openAiSongSuggestions.split('\n'):

    # Search Spotify for Object 
    songSearchResults = spotifyObject.search(q = currentSongTitle, limit = 1)


    # Retrieve the trackURI of the first song searched by spotify and print it 
    if songSearchResults['tracks']['items']:
        trackURI = songSearchResults['tracks']['items'][0]['uri']
    
        # Add the song to the playlist 
        spotifyObject.user_playlist_add_tracks(user = spotifyUsername, playlist_id = playlistID, tracks= [trackURI] )
